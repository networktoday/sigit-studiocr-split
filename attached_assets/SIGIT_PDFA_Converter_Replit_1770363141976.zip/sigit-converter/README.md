# SIGIT PDF/A Converter

Webapp per la conversione automatica di documenti PDF in formato **PDF/A-1b**, compatibile con il sistema **SIGIT** per il Deposito Telematico degli atti giudiziari.

## Funzionalità

- **Caricamento multi-documento**: drag & drop o selezione multipla
- **Conversione PDF/A-1b**: via Ghostscript (ISO 19005-1)
- **Split automatico**: file > 9 MB vengono suddivisi automaticamente con suffisso numerico (`_parte1`, `_parte2`, ecc.)
- **Download ZIP**: tutti i file convertiti in un unico archivio
- **Pulizia automatica**: i file vengono rimossi dal server dopo il download
- **Nessun database**: tutto in-memory e filesystem temporaneo

## Setup su Replit

1. Crea un nuovo Repl Python su [replit.com](https://replit.com)
2. Carica tutti i file del progetto
3. Assicurati che `replit.nix` installi `ghostscript` e `qpdf`
4. Clicca **Run**

## Struttura del progetto

```
├── main.py              # Backend Flask
├── templates/
│   └── index.html       # Frontend (Single Page App)
├── requirements.txt     # Dipendenze Python
├── .replit              # Configurazione Replit
├── replit.nix           # Pacchetti di sistema (Nix)
└── README.md
```

## Specifiche tecniche

| Parametro | Valore |
|-----------|--------|
| Formato output | PDF/A-1b (ISO 19005-1) |
| Dimensione max per file | 9 MB |
| Motore di conversione | Ghostscript |
| Motore di split | QPDF |
| Framework | Flask |

## Note per gli avvocati

- I file superiori a 9 MB vengono automaticamente divisi in parti
- Ogni parte mantiene il nome originale con suffisso `_parteN`
- Il formato PDF/A-1b è conforme ai requisiti del SIGIT
- I file vengono elaborati in locale e rimossi dopo il download
