import os
import uuid
import shutil
import subprocess
import zipfile
import math
from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB max total upload
app.config['UPLOAD_FOLDER'] = '/tmp/sigit_uploads'
app.config['OUTPUT_FOLDER'] = '/tmp/sigit_outputs'

MAX_FILE_SIZE_MB = 9
MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024


def ensure_dirs():
    """Create necessary directories."""
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)


def get_pdf_page_count(pdf_path):
    """Get the number of pages in a PDF using Ghostscript."""
    try:
        result = subprocess.run(
            ['gs', '-q', '-dNODISPLAY', '-dNOSAFER',
             '-c', f'({pdf_path}) (r) file runpdfbegin pdfpagecount = quit'],
            capture_output=True, text=True, timeout=30
        )
        return int(result.stdout.strip())
    except Exception:
        # Fallback: use qpdf
        try:
            result = subprocess.run(
                ['qpdf', '--show-npages', pdf_path],
                capture_output=True, text=True, timeout=30
            )
            return int(result.stdout.strip())
        except Exception:
            return 0


def split_pdf_by_pages(pdf_path, output_dir, base_name, max_size_bytes):
    """
    Split a PDF into chunks that are each under max_size_bytes.
    Uses binary search on page ranges to find optimal splits.
    Returns list of output file paths.
    """
    total_pages = get_pdf_page_count(pdf_path)
    if total_pages == 0:
        return []

    output_files = []
    current_start = 1
    part_num = 1

    while current_start <= total_pages:
        # Try progressively fewer pages until we get under the size limit
        end_page = total_pages
        best_end = current_start  # At minimum, one page

        while current_start <= end_page:
            mid = (current_start + end_page) // 2
            if mid < current_start:
                mid = current_start

            # Extract pages current_start to mid
            temp_output = os.path.join(output_dir, f'_temp_split_{part_num}.pdf')
            try:
                subprocess.run(
                    ['qpdf', pdf_path,
                     '--pages', pdf_path, f'{current_start}-{mid}', '--',
                     temp_output],
                    capture_output=True, text=True, timeout=60,
                    check=True
                )

                file_size = os.path.getsize(temp_output)

                if file_size <= max_size_bytes:
                    best_end = mid
                    if mid == end_page:
                        break
                    current_start_search = mid + 1
                    # Try more pages
                    if current_start_search > end_page:
                        break
                    # Clean temp and try with more pages
                    os.remove(temp_output)
                    # Binary search upper half
                    low, high = mid + 1, end_page
                    while low <= high:
                        test_mid = (low + high) // 2
                        temp_output2 = os.path.join(output_dir, f'_temp_split_{part_num}_test.pdf')
                        try:
                            subprocess.run(
                                ['qpdf', pdf_path,
                                 '--pages', pdf_path, f'{current_start}-{test_mid}', '--',
                                 temp_output2],
                                capture_output=True, text=True, timeout=60,
                                check=True
                            )
                            test_size = os.path.getsize(temp_output2)
                            os.remove(temp_output2)

                            if test_size <= max_size_bytes:
                                best_end = test_mid
                                low = test_mid + 1
                            else:
                                high = test_mid - 1
                        except Exception:
                            if os.path.exists(temp_output2):
                                os.remove(temp_output2)
                            high = test_mid - 1
                    break
                else:
                    os.remove(temp_output)
                    if mid == current_start:
                        # Single page is too large, we have to include it anyway
                        best_end = current_start
                        break
                    end_page = mid - 1

            except Exception:
                if os.path.exists(temp_output):
                    os.remove(temp_output)
                if mid == current_start:
                    best_end = current_start
                    break
                end_page = mid - 1

        # Now extract the final chunk: current_start to best_end
        # Clean name for the part
        part_suffix = f"_parte{part_num}"
        out_name = f"{base_name}{part_suffix}.pdf"
        out_path = os.path.join(output_dir, out_name)

        try:
            subprocess.run(
                ['qpdf', pdf_path,
                 '--pages', pdf_path, f'{current_start}-{best_end}', '--',
                 out_path],
                capture_output=True, text=True, timeout=60,
                check=True
            )
            output_files.append(out_path)
        except Exception as e:
            print(f"Error splitting pages {current_start}-{best_end}: {e}")

        current_start = best_end + 1
        part_num += 1

    # Clean up temp files
    for f in os.listdir(output_dir):
        if f.startswith('_temp_split_'):
            os.remove(os.path.join(output_dir, f))

    return output_files


def convert_to_pdfa(input_path, output_path):
    """Convert a PDF to PDF/A-1b using Ghostscript."""
    try:
        result = subprocess.run(
            ['gs', '-dPDFA=1', '-dBATCH', '-dNOPAUSE', '-dNOOUTERSAVE',
             '-sColorConversionStrategy=UseDeviceIndependentColor',
             '-sDEVICE=pdfwrite',
             '-dPDFACompatibilityPolicy=1',
             '-dCompatibilityLevel=1.4',
             '-sOutputFile=' + output_path,
             input_path],
            capture_output=True, text=True, timeout=120
        )

        if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
            return True, None
        else:
            return False, result.stderr or "Conversione fallita: file di output vuoto"

    except subprocess.TimeoutExpired:
        return False, "Timeout durante la conversione"
    except Exception as e:
        return False, str(e)


def process_pdf(file_path, original_filename, session_dir):
    """
    Process a single PDF:
    1. Check size
    2. Split if > 9MB
    3. Convert each piece to PDF/A
    Returns list of result dicts.
    """
    results = []
    base_name = os.path.splitext(original_filename)[0]
    file_size = os.path.getsize(file_path)

    split_dir = os.path.join(session_dir, 'splits')
    os.makedirs(split_dir, exist_ok=True)
    pdfa_dir = os.path.join(session_dir, 'pdfa')
    os.makedirs(pdfa_dir, exist_ok=True)

    files_to_convert = []

    if file_size > MAX_FILE_SIZE_BYTES:
        # Need to split
        split_files = split_pdf_by_pages(file_path, split_dir, base_name, MAX_FILE_SIZE_BYTES)
        if not split_files:
            return [{'filename': original_filename, 'status': 'error',
                      'message': 'Impossibile dividere il file'}]
        files_to_convert = [(f, os.path.basename(f)) for f in split_files]
    else:
        files_to_convert = [(file_path, original_filename)]

    for src_path, fname in files_to_convert:
        out_name = os.path.splitext(fname)[0] + '_PDFA.pdf'
        out_path = os.path.join(pdfa_dir, out_name)

        success, error = convert_to_pdfa(src_path, out_path)

        if success:
            final_size = os.path.getsize(out_path)
            # Check if PDF/A conversion made it exceed the limit
            if final_size > MAX_FILE_SIZE_BYTES:
                # Re-split the converted file
                os.remove(out_path)
                re_split_base = os.path.splitext(fname)[0] + '_PDFA'
                re_split_files = split_pdf_by_pages(src_path, split_dir, re_split_base, MAX_FILE_SIZE_BYTES)
                for rsf in re_split_files:
                    rsf_out = os.path.join(pdfa_dir, os.path.basename(rsf).replace('.pdf', '_PDFA.pdf'))
                    s, e = convert_to_pdfa(rsf, rsf_out)
                    results.append({
                        'filename': os.path.basename(rsf_out) if s else os.path.basename(rsf),
                        'status': 'success' if s else 'error',
                        'message': None if s else e,
                        'size_mb': round(os.path.getsize(rsf_out) / (1024 * 1024), 2) if s else None,
                        'path': rsf_out if s else None
                    })
            else:
                results.append({
                    'filename': out_name,
                    'status': 'success',
                    'message': None,
                    'size_mb': round(final_size / (1024 * 1024), 2),
                    'path': out_path
                })
        else:
            results.append({
                'filename': fname,
                'status': 'error',
                'message': error,
                'path': None
            })

    return results


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload_files():
    ensure_dirs()

    if 'files[]' not in request.files:
        return jsonify({'error': 'Nessun file caricato'}), 400

    files = request.files.getlist('files[]')
    if not files or all(f.filename == '' for f in files):
        return jsonify({'error': 'Nessun file selezionato'}), 400

    # Create a unique session directory
    session_id = str(uuid.uuid4())
    session_dir = os.path.join(app.config['OUTPUT_FOLDER'], session_id)
    os.makedirs(session_dir, exist_ok=True)

    all_results = []
    total_files = len([f for f in files if f.filename])

    for file in files:
        if file.filename == '':
            continue

        if not file.filename.lower().endswith('.pdf'):
            all_results.append({
                'filename': file.filename,
                'status': 'error',
                'message': 'Il file non è un PDF'
            })
            continue

        # Save uploaded file
        safe_name = secure_filename(file.filename)
        upload_path = os.path.join(session_dir, 'uploads')
        os.makedirs(upload_path, exist_ok=True)
        file_path = os.path.join(upload_path, safe_name)
        file.save(file_path)

        # Process the file
        results = process_pdf(file_path, safe_name, session_dir)
        all_results.extend(results)

    # Create ZIP of all successful conversions
    zip_path = None
    successful = [r for r in all_results if r.get('status') == 'success' and r.get('path')]

    if successful:
        zip_name = f'SIGIT_PDFA_{session_id[:8]}.zip'
        zip_path = os.path.join(session_dir, zip_name)
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for r in successful:
                if r['path'] and os.path.exists(r['path']):
                    zf.write(r['path'], os.path.basename(r['path']))

    # Clean up paths from results (don't expose server paths)
    for r in all_results:
        r.pop('path', None)

    return jsonify({
        'session_id': session_id,
        'total_uploaded': total_files,
        'total_output': len(successful),
        'results': all_results,
        'zip_available': zip_path is not None
    })


@app.route('/download/<session_id>')
def download_zip(session_id):
    session_dir = os.path.join(app.config['OUTPUT_FOLDER'], session_id)

    # Find the ZIP file
    for f in os.listdir(session_dir):
        if f.endswith('.zip'):
            return send_file(
                os.path.join(session_dir, f),
                as_attachment=True,
                download_name=f
            )

    return jsonify({'error': 'File non trovato'}), 404


@app.route('/cleanup/<session_id>', methods=['POST'])
def cleanup(session_id):
    """Clean up session files."""
    session_dir = os.path.join(app.config['OUTPUT_FOLDER'], session_id)
    if os.path.exists(session_dir):
        shutil.rmtree(session_dir)
    return jsonify({'status': 'ok'})


if __name__ == '__main__':
    ensure_dirs()
    app.run(host='0.0.0.0', port=5000, debug=True)
